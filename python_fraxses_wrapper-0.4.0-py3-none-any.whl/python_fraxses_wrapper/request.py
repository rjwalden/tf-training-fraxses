import json
from typing import Any, Union
from .kafka_core import WrapperProducer
from .response import Response
from .logging import LogRequest
from .serialising import DataClassEncoder
from .logging import wrap_log_message
from .customprotocol import DataClass


class WrapperRequest:
    def __init__(
        self, key: dict, payload: DataClass, producer: WrapperProducer, encryption
    ):
        self.key = key
        self.payload = payload
        self.producer = producer
        self.encryption = encryption

    def respond(self, response: Response):
        message = self._resolve_message(response)
        self.producer.produce(payload_bytes=message, key=self.key)

    def log(self, msg: str):
        message = self._resolve_message(wrap_log_message(msg))
        self.producer.log(payload_bytes=message, key=self.key)

    def log_audit(self, msg: str, audit: str):
        message = self._resolve_message(wrap_log_message(msg, audit))
        self.producer.log(payload_bytes=message, key=self.key)

    def _resolve_message(self, packet: Union[Response, LogRequest]) -> bytes:
        payload_bytes = json.dumps(packet, cls=DataClassEncoder).encode()
        if self.key["encrypt"]:
            return self.encryption.encrypt(
                payload_bytes, self.key["correlationId"].encode()
            )
        return payload_bytes
