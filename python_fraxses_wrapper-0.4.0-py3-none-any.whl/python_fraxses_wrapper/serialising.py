from json import JSONEncoder
from typing import Any
import dataclasses
import re

camel_pattern = re.compile(r"([A-Z])")
snake_pattern = re.compile(r"_([a-z])")


class DataClassEncoder(JSONEncoder):
    """
    An enhanced JSONEncoder that will correctly serialise dataclass objects. Standard Python types should work fine as well, including dicts.
    """

    def default(self, o, convert_case=True):
        if dataclasses.is_dataclass(o):
            dict_value = dataclasses.asdict(o)
            if not convert_case:
                return dict_value
            clean_value = {}
            for (key, value) in dict_value.items():
                clean_value[to_camel_case(key)] = value
            return clean_value
        return super().default(o)


def to_camel_case(snake_str):
    return snake_pattern.sub(lambda x: x.group(1).upper(), snake_str)


def to_snake_case(camel_str):
    return camel_pattern.sub(lambda x: "_" + x.group(1).lower(), camel_str)


def dict_to_snake_case(obj):
    return {to_snake_case(k): v for k, v in obj.items()}
