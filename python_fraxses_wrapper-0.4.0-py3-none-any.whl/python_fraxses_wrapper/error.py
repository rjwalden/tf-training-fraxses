from .encryption import FraxsesEncryption
from .kafka_core import WrapperProducer
from .logging import wrap_log_message
from .serialising import DataClassEncoder
import json
import traceback


class WrapperError:
    """
    The default error returned by the FraxsesWrapper during the course of a recoverable error. This class should not
    be instantiated directly but will be yielded by the Wrapper if an issue occurs deserialising the incoming packet.
    This is not an exception type and cannot be caught but it does wrap an exception which can be accessed by
    self.exception if needed. If all you want is a stack trace, prefer the log method instead.
    """

    def __init__(
        self,
        key: dict,
        error: Exception,
        encryption: FraxsesEncryption,
        producer: WrapperProducer,
    ):
        self.key = key
        self.exception = error
        self.producer = producer
        self.encryption = encryption

    def format_error(self) -> str:
        """
        Returns the exception message and stack trace formatted into a string.
        """
        stack_trace = "".join(
            traceback.format_exception(
                type(self.exception),
                self.exception,
                self.exception.__traceback__,
            )
        )
        return f"{self.exception}{stack_trace}"

    def log(self):
        """
        Formats the wrapped exception object via the format method and writes it to the logging topic wrapped
        as a JSON object containing some useful information such as timestamps.
        """
        message = self.format_error()
        packet = wrap_log_message(message)
        payload_bytes = json.dumps(packet, cls=DataClassEncoder).encode()
        if self.key["encrypt"]:
            payload_bytes = self.encryption.encrypt(
                payload_bytes, self.key["correlationId"].encode()
            )
        self.producer.log(payload_bytes, self.key)