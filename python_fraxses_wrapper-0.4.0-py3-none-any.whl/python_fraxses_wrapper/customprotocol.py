from typing import Dict
from typing_extensions import Protocol


class DataClass(Protocol):
    """
    Typing protocol to enforce that incoming types are dataclasses, this is to ensure that
    serialisation works correctly because types with complex constructors will cause problems. Users
    shouldn't need to use this class but may choose to do so to ensure typings are correctly checked and passed.
    """

    __dataclass_fields__: Dict
