import os

KAFKA_BOOTSTRAP_SERVERS: str = "KAFKA_BOOTSTRAP_SERVERS"
REQUEST_TOPIC: str = "REQUEST_TOPIC"
LOG_TOPIC: str = "LOG_TOPIC"
FRAXSES_CLIENT_SECRET: str = "FRAXSES_CLIENT_SECRET"

DEFAULTS: dict = {LOG_TOPIC: "logging"}


def _validate_secret(secret):
    if len(secret.encode()) < 10:
        raise Exception("The FRAXSES_CLIENT_SECRET should be at least 10 bytes long.")


VALIDATORS = {FRAXSES_CLIENT_SECRET: _validate_secret}


class EnvSource:
    def resolve(self, name: str) -> str:
        raise Exception("This method should be overridden in subclasses")


class Env(EnvSource):
    def resolve(self, name: str) -> str:
        variable = os.environ.get(name)
        if variable:
            if VALIDATORS.get(name):
                VALIDATORS[name](variable)
        if not variable:
            variable = DEFAULTS.get(name)
        if not variable:
            raise Exception(
                f"Please set the {name} environment variable, no default is availble for this."
            )
        return variable
