from typing import Any
from dataclasses import dataclass


@dataclass
class ResponseResult:
    success: bool
    error: str


@dataclass
class Response:
    result: ResponseResult
    payload: Any
