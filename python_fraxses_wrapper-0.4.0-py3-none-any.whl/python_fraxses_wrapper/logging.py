from dataclasses import dataclass
from typing import Any, Optional
from datetime import date, datetime
from dateutil.tz import tzlocal

# This matches Rust's Chrono modules's default time format
BASE_DATE_FORMAT = "%Y-%m-%d %H:%M:%S %Z"


@dataclass
class Performance:
    """
    Primarily for internal use. Prefer using the wrap_log_message contained in this module.
    """

    processors: Optional[int]
    total: Optional[int]
    free: Optional[int]
    used: Optional[int]
    max: Optional[int]
    used_perc: Optional[int]


@dataclass
class Payload:
    """
    Primarily for internal use. Prefer using the wrap_log_message contained in this module.
    """

    timestamp: str
    timestamp_in_milliseconds: int
    performance: Performance
    audit: Optional[str]
    message: Any


@dataclass
class Content:
    """
    Primarily for internal use. Prefer using the wrap_log_message contained in this module.
    """

    payload: Payload


@dataclass
class LogRequest:
    """
    Primarily for internal use. Prefer using the wrap_log_message contained in this module.
    """

    content: Content


def wrap_log_message(message: str, audit: Optional[str] = None) -> LogRequest:
    """
    Wraps a string into a LogRequest object for use in logging.

    Args:
        message (str): The relevant message to log. This should contain any useful information for debugging or tracing.
        audit (Optional[str]): An audit string. If this is not set it will default to None.

    Returns:
        A LogRequest object containing useful information for logging and tracing.
    """
    dt = datetime.now(tzlocal())
    unix_time = dt.timestamp() * 1000
    return LogRequest(
        Content(
            Payload(
                timestamp=dt.strftime(BASE_DATE_FORMAT),
                timestamp_in_milliseconds=int(unix_time),
                performance=Performance(None, None, None, None, None, None),
                audit=audit,
                message=message,
            )
        )
    )