from __future__ import annotations
from typing import Optional, Any, Type, Generator, List, Union
from types import SimpleNamespace as Namespace
import json
from .response import Response, ResponseResult
from .request import WrapperRequest
from .env_source import EnvSource, Env
from .serialising import dict_to_snake_case
from confluent_kafka import KafkaException
from .kafka_core import WrapperProducer, WrapperConsumer
from .encryption import FraxsesEncryption, TdesEncryption, FRAXSES_DEFAULT_KEY
import traceback
from .error import WrapperError
from .customprotocol import DataClass


class FraxsesWrapper:
    """
    This class is the primary use case for this library. This will allow the developer access to read and write messages to the
    internal Fraxses system via Kakfa.

    Args:
        group_id (str): The group id that will be used to consume messages from kakfa.
        encryption (Optional[FraxsesEncryption]): An implementation of the Fraxses encryption class. Generally this should not be set as it will
            default to the standard encryption, which is a good default for most use cases.
        topic (str): The topic that this class will consume messages from. Generally this should not be set as it will be read from an environment variable
        env_source (Optional[EnvSource]): An implementation of the EnvSource class in this project. Generally this should not be set as a default will be
            used but creating a custom implementation can be useful for tests. See the integration tests contained in this project for more information.

    """

    def __init__(
        self,
        group_id: str,
        encryption: Optional[FraxsesEncryption] = None,
        topic: Optional[str] = None,
        env_source: Optional[EnvSource] = None,
    ):
        self.env_source = env_source

        self.group_id = group_id
        self.bootstrap_servers: str

        if not self.env_source:
            self.env_source = Env()

        if topic:
            self.topic = topic
        else:
            self.topic = self.env_source.resolve("REQUEST_TOPIC")
        self.log_topic = self.env_source.resolve("LOG_TOPIC")
        self.bootstrap_servers = self.env_source.resolve("KAFKA_BOOTSTRAP_SERVERS")
        self.client_secret = self.env_source.resolve("FRAXSES_CLIENT_SECRET").encode()
        self.transaction_id: Optional[str] = None

    def as_transactional(self, transaction_id: str) -> FraxsesWrapper:
        """
        Sets transaction to be active within this Wrapper object. This should be called before build or before using this in a with block.

        Returns:
            Returns self
        """
        self.transaction_id = transaction_id
        return self

    def build(self) -> FraxsesWrapper:
        """
        Initialises the consumer and producer and transactions (if enabled). Calling this method is identical to use within a with block,
        which should be the preffered method of use.

        Returns:
            Returns self
        """
        self.consumer = WrapperConsumer(
            self.bootstrap_servers, self.group_id, self.topic
        ).build()
        self.producer = WrapperProducer(self.bootstrap_servers, self.log_topic)
        if self.transaction_id:
            self.producer.as_transactional(self.transaction_id)
        self.producer = self.producer.build()
        self.encryption = TdesEncryption(self.client_secret)
        return self

    def close(self):
        """
        Closes both the consumer and producer, flushing offsets in the process. This class should not be used after invoking this method.
        """
        self.consumer.close()
        self.producer.close()

    def __enter__(self):
        self.build()

    def __exit__(self, type, value, traceback):
        self.close()

    def receive(
        self, deserialise_class: Type = Namespace
    ) -> Generator[Union[WrapperRequest, WrapperError], None, None]:
        """
        Sets up an infinite generator object that will yield either a valid Fraxses Wrapper Request object or a Fraxses Error
        """

        message_generator = self.consumer.poll()
        for kafka_message in message_generator:
            key_value = self._resolve_key(kafka_message)
            if not key_value:
                # Similar behavior to the Rust implementation - we got a borked message but there's little we can do
                # since we don't have enough information to either yield a message or log
                continue
            try:
                if not kafka_message:
                    message_generator.send(True)
                    continue

                message_value = self._resolve_message(key_value, kafka_message.value())
                message_payload = unwrap_to(deserialise_class, message_value["payload"])

                yield WrapperRequest(
                    key=key_value,
                    payload=message_payload,
                    producer=self.producer,
                    encryption=self.encryption,
                )
            except KafkaException as e:
                message_generator.close()
                raise
            except Exception as e:
                yield WrapperError(
                    key=key_value,
                    error=e,
                    encryption=self.encryption,
                    producer=self.producer,
                )

    def _resolve_message(self, key: dict, message: bytes) -> dict:
        if key.get("encrypt"):

            value = self.encryption.decrypt(message, key["correlationId"].encode())
            return json.loads(value)
        else:
            return json.loads(message)

    def _resolve_key(self, kafka_message):
        try:
            return json.loads(kafka_message.key())
        except Exception as e:
            print(f"Wrapper could not interpret key or no key received. {e}")
            return None


def unwrap_to(deserialise_class: Type, json_data: dict) -> DataClass:
    case_converted_json = dict_to_snake_case(json_data)
    return deserialise_class(**case_converted_json)
