from typing import ByteString, Optional
from Crypto.Cipher import DES3, AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
from os import urandom

FRAXSES_DEFAULT_KEY = b64decode(b"ZnJAWCRlJER1aXJkMy41Qg==")

AES_IV_SIZE = 16
AES_KEY_LOWER = 10
AES_KEY_UPPER = 12

TDES_KEY_PART = 8
TDES_IV_SIZE = 8
TDES_PAD_LENGTH = 16


class FraxsesEncryption:
    """
    Base class for Fraxses encryption.
    """

    def __init__(self, client_key: bytes):
        self.client_key = client_key


class TdesEncryption(FraxsesEncryption):
    """
    Implentation of Triple DES Encryption cipher in CBC mode. All the public methods in this class
    will fail if the passed key degrades to single DES and raise a ValueError.
    """

    def __init__(self, client_key: bytes):
        super().__init__(client_key)

    def _extract_part_key(self, part_key: Optional[bytes]) -> bytes:
        if not part_key or len(part_key) < TDES_KEY_PART:
            print(
                f"The part key used in aes encryption is shorter than {TDES_KEY_PART} bytes. Defaulting to client key"
            )
            return self.client_key
        return part_key

    def _iv(self) -> bytes:
        return urandom(TDES_IV_SIZE)

    def _key(self, part_key) -> bytes:
        key_parts = bytearray(part_key[:TDES_KEY_PART])
        key_parts.extend(bytearray(FRAXSES_DEFAULT_KEY[:TDES_KEY_PART]))
        key_parts.extend(bytearray(self.client_key[:TDES_KEY_PART]))
        return bytes(key_parts)

    def _split_raw_cipher_text(self, raw_cipher_text):
        raw_cipher_text = bytearray(raw_cipher_text)
        return raw_cipher_text[:TDES_IV_SIZE], raw_cipher_text[TDES_IV_SIZE:]

    def encrypt(self, value: bytes, part_key: Optional[bytes]) -> bytes:
        """
        Encrypts the incoming value parameter using the TDES cipher. The part key is the client portion of the
        key used in the key derivation scheme. While this is an optional parameter it's highly encouraged
        to supply this parameter as not using it will likely result in degradation of the cipher to single DES.
        This method returns the encrypted value as a bytes object which can be turned into a string using .encode()
        """
        part_key = self._extract_part_key(part_key)
        key = self._key(part_key)
        iv = self._iv()

        while True:
            try:
                key = DES3.adjust_key_parity(key)
                break
            except ValueError:
                pass

        cipher = DES3.new(key, DES3.MODE_CBC, iv=iv)

        padded_bytes = pad(value, TDES_PAD_LENGTH)

        final_message = bytearray()
        final_message.extend(iv)
        final_message.extend(cipher.encrypt(padded_bytes))
        return bytes(final_message)

    def decrypt(self, ciphered_text: bytes, part_key: bytes) -> bytes:
        """
        Decrypts the given ciphered_text value using the TDES cipher. The part key is the client portion of the
        key used in the key derivation scheme. While this is an optional parameter it's highly encouraged
        to supply this parameter as not using it will likely result in degradation of the cipher to single DES.
        This method returns the encrypted value as a bytes object which can be turned into a string using .encode()
        The iv used to encrypt the packet is prepended to the cipher text.
        """
        part_key = self._extract_part_key(part_key)
        key = self._key(part_key)
        iv, cipher_text = self._split_raw_cipher_text(ciphered_text)
        des = DES3.new(key, DES3.MODE_CBC, iv=iv)
        return unpad(des.decrypt(cipher_text), TDES_PAD_LENGTH)


class AesEncryption(FraxsesEncryption):

    """
    Implentation of AES-256 Encryption cipher in CBC mode.
    """

    def __init__(self, client_key: bytes):
        super().__init__(client_key)

    def _extract_part_key(self, part_key: Optional[bytes]) -> bytes:
        if not part_key or len(part_key) < AES_KEY_LOWER:
            print(
                f"The part key used in aes encryption is shorter than {AES_KEY_LOWER} bytes. Defaulting to client key"
            )
            return self.client_key
        return part_key

    def _iv(self) -> bytes:
        return urandom(AES_IV_SIZE)

    def _key(self, part_key):
        key_parts = bytearray(part_key[:AES_KEY_LOWER])
        key_parts.extend(bytearray(FRAXSES_DEFAULT_KEY[:AES_KEY_LOWER]))
        key_parts.extend(bytearray(self.client_key[:AES_KEY_UPPER]))
        return bytes(key_parts)

    def _split_raw_cipher_text(self, raw_cipher_text):
        raw_cipher_text = bytearray(raw_cipher_text)
        return raw_cipher_text[:AES_IV_SIZE], raw_cipher_text[AES_IV_SIZE:]

    def encrypt(self, value: bytes, part_key: Optional[bytes]) -> bytes:
        """
        Encrypts the incoming value parameter using the AES-256 cipher.
        This method returns the encrypted value as a bytes object which can be turned into a string using .encode()
        The iv used to encrypt the packet is prepended to the cipher text.
        """
        part_key = self._extract_part_key(part_key)
        key = self._key(part_key)
        iv = self._iv()
        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        padded_bytes = pad(value, AES.block_size)

        final_message = bytearray()
        final_message.extend(iv)
        final_message.extend(cipher.encrypt(padded_bytes))
        return bytes(final_message)

    def decrypt(self, ciphered_text: bytes, part_key: bytes) -> bytes:
        """
        Decrypts the incoming ciphered_text parameter using the AES-256 cipher.
        This method returns the decrypted value as a bytes object which can be turned into a string using .encode()
        """
        part_key = self._extract_part_key(part_key)
        key = self._key(part_key)
        iv, cipher_text = self._split_raw_cipher_text(ciphered_text)

        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        return unpad(cipher.decrypt(cipher_text), AES.block_size)